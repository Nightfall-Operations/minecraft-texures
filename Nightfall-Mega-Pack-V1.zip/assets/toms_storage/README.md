# Toms-Storage
Simple vanilla style storage mod for Minecraft
![Banner](https://github.com/tom5454/Toms-Storage/blob/master/banner.png)
Mod Spotlight Video:  
[![My Spotlight Video](https://img.youtube.com/vi/RwRKNhZ7uec/0.jpg)](https://www.youtube.com/watch?v=RwRKNhZ7uec)
