# Item Filters 

[![](http://cf.way2muchnoise.eu/309674.svg) ![](http://cf.way2muchnoise.eu/versions/309674.svg)](https://www.curseforge.com/minecraft/mc-mods/item-filters)